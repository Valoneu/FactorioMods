My tweaks i use for K2SE
- buffed modules
- mfab is affected by beacons
- not so insane scaling of spaceship research 

todo:

- merge it with the old mod
